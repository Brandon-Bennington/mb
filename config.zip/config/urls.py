from django.contrib import admin
from django.urls import include, path
from posts import views  # Import your views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.HomePageView.as_view(), name="home"),  # Home page
    path("about/", views.AboutPageView.as_view(), name="about"),  # About page
    path("posts/", include("posts.urls")),  # Include posts app URLs
]
