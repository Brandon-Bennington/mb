from django.urls import path
from posts import views
from .views import HomePageView, AboutPageView

urlpatterns = [
    # Homepage
    path("", HomePageView.as_view(), name="home"),

    # About page
    path("about/", AboutPageView.as_view(), name="about"),

    # Blog posts
    path('posts/', views.PostListView.as_view(), name='list'),  # For listing posts
    path('posts/<int:pk>/', views.PostDetailView.as_view(), name='post_detail'),  # For detailed view of a single post
]
