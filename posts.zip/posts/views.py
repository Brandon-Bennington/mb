from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    TemplateView
)

from .models import Post

class HomePageView(TemplateView):
    template_name = 'pages/home.html'

class AboutPageView(TemplateView):
    template_name = 'pages/about.html'

class PostListView(ListView):
    template_name = "posts/list.html"
    model = Post
    context_object_name = 'posts'

class PostDetailView(DetailView):
    template_name = "posts/detail.html"
    model = Post
    context_object_name = 'posts'

class PostCreateView(CreateView):
    template_name = "posts/new.html"
    model = Post
    fields = ["title", "subtitle", "body"]